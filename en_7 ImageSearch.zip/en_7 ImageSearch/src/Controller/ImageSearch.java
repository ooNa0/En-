package Controller;

public class ImageSearch {
	public static void main(String[] args) {
		MainMenu menu = new MainMenu();
		menu.startMenu();
	}
}
